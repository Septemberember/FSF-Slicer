public class Calculator {
    public static int calculate(int num1, int num2, char operator) {
        int result;
        throw new ArithmeticException("modulo by zero");
    }
}

