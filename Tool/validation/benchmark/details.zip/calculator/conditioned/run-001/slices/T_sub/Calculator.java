public class Calculator {
    public static int calculate(int num1, int num2, char operator) {
        int result;
        result = (num1 - num2);
        return result;
    }
}

