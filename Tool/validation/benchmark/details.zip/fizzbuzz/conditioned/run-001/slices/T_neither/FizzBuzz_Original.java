// FizzBuzz_Original: returns 3 for multiples of 3, 5 for multiples of 5, and their sum if both.

public class FizzBuzz_Original {

    // Computes a simple sum based on divisibility by 3 and 5.
    public static int fizzBuzz(int n) {
        int res = 0;
        return res;
    }
}