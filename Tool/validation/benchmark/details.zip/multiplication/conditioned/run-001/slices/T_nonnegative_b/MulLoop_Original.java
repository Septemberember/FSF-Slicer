/**
 * Utility: compute multiplication using repeated addition.
 * This class demonstrates a straightforward, loop-based approach.
 */
public class MulLoop_Original {

	// Public API: multiply two integers by repeated addition.
	public static int mulLoop(int a, int b) {
        int res = 0;
        for (int i = 0; (i < b); i++) {
            res = (res + a);
        }
        return res;
    }

}